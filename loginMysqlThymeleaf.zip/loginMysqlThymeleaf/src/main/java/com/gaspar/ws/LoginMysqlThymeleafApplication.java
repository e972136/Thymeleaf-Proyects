package com.gaspar.ws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginMysqlThymeleafApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginMysqlThymeleafApplication.class, args);
	}

}
